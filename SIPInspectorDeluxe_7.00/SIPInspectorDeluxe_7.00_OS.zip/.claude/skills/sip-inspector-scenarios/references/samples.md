# Sample scenarios (the `scenarios/` folder of SIP Inspector)

Every sample starts with a header comment that lists its messages. Read the closest one(s) before
writing; copy their messages. Pairs marked ↔ are tested against each other, so a client sample and its
server are a known-good starting point for both sides.

## Registration

| Scenario | What it shows |
|---|---|
| Reg_client.txt ↔ Reg_server.txt | REGISTER, optional 100/401, REGISTER with Authorization (optional send) |
| Reg_branching_client.txt ↔ Reg_server.txt | same, with `condition=if (Resp == 404) goto end` |
| Reg_series_client.txt | many users, one per row of a values file (`values/Reg_series_values.txt`) |
| Asterisk_reg_client.txt | REGISTER against Asterisk |
| Port_scan_client.txt | REGISTER to many addresses/ports from a values file (`cmd_setRemote=[$subnet].[field0]:[field1]`) |

## Calls

| Scenario | What it shows |
|---|---|
| Reg_call_client.txt ↔ Reg_call_server.txt | register, `cmd_NewDialog`, INVITE/ACK/pcap/BYE; server answers with SDP and plays a pcap |
| Reg_auth_call_client.txt ↔ Reg_auth_call_server.txt | REGISTER challenged with 401, INVITE challenged with 407 (ACK for the 407, INVITE with Proxy-Authorization), live speech |
| Reg_auth_call_advanced_client.txt ↔ Reg_auth_call_server.txt | the same, branching on whichever challenge comes |
| Perf_cps_client.txt ↔ Perf_cps_server.txt | shortest call, no media - call-rate load tests |
| Perf_rtp_client.txt ↔ Perf_rtp_server.txt | call with G.711 both ways - RTP load tests |
| PBX_call_series_client.txt | outgoing calls, one per values-file row |
| PBX_reg_incoming_call_client.txt | registers every minute (label/goto loop) and answers incoming calls in a new dialog |
| Asterisk_reg_incoming_call_client.txt / Asterisk_reg_outgoing_call_client.txt | the same against Asterisk |
| PRACK_client.txt ↔ PRACK_server.txt | 100rel: reliable 180 with RSeq, PRACK with `RAck: [val_last_RSeq:] [val_last_CSeq:]` |
| Record_route_client.txt ↔ Record_route_server.txt | Record-Route saved with `set_Variable` (`Record-Route-1:` ...) and sent back as Route |
| Call_codec_change_signaling_client.txt ↔ Call_codec_change_signaling_server.txt | mid-call re-INVITE changing the codec |
| PBX_call_codec_change_reinvite_client.txt | the same through a proxy |
| Call_codec_change_rtp_only_client.txt | RTP codec change without signalling (two pcaps with `duration=` one after the other) |
| HexBody_client.txt ↔ HexBody_server.txt | multipart body with a QSIG part in `[hex]...[/hex]` |
| Call_cancel_client.txt ↔ Call_cancel_server.txt | CANCEL while ringing: CANCEL and ACK with the INVITE branch (`branch=z9hG4bK[call_number]inv1`), 200 to the CANCEL, 487 with `CSeq: [$invCSeq] INVITE` saved by `set_Variable` |
| Call_busy_client.txt ↔ Call_busy_server.txt | rejected call: 486 Busy Here and its ACK with the INVITE branch |
| Call_hold_resume_client.txt ↔ Call_hold_resume_server.txt | hold and resume: re-INVITE sendonly/recvonly, then sendrecv, o= version raised per offer |
| Options_ping_client.txt ↔ Options_ping_server.txt | out-of-dialog OPTIONS keepalive with `assert=status 200` and `assert=responseTime 500` |
| Message_client.txt ↔ Message_server.txt | MESSAGE (text/plain), 200 or 202 accepted via `condition=if (Resp == 202) goto done` |

## Media, DTMF, video, SRTP, WebSocket

| Scenario | What it shows |
|---|---|
| Call_speech_dials_client.txt ↔ Call_speech_dials_server.txt | live speech, random digits (`rndVal=rand[...]`, `cmd_DialDigits=[$rndVal]`) - needs a sound device |
| Call_speech_dials_asserts_client.txt | the same with `assert=` entries (status, header, body, responseTime, rtp packets/loss/mos) |
| Call_video_client.txt ↔ Call_video_server.txt | H.264 video: `m=video [video_port]`, `cmd_PlayPcap=...;video=true`, `waitVideo=30` |
| SRTP_reg_incoming_call_client.txt / SRTP_reg_outgoing_call_client.txt | RTP/SAVP with `a=crypto` |
| WebRTC_reg_incoming_call_server.txt / WebRTC_reg_outgoing_call_server.txt | WebSocket server for a browser (WebRTC) client |

## Subscriptions and notifications

| Scenario | What it shows |
|---|---|
| SUBSCRIBE_dialog_client.txt ↔ SUBSCRIBE_dialog_server.txt | dialog event package (BLF): SUBSCRIBE, 200, four NOTIFYs answered with 200 |
| Reg_subscribe_call_client.txt ↔ Reg_subscribe_call_server.txt | register, message-summary SUBSCRIBE, NOTIFY from the server (`NOTIFY [$contact]`), then a call |
| Reg_subscribe_incoming_call_client.txt ↔ Reg_subscribe_incoming_call_server.txt | the same, the server calls the client |

## Transfer, B2BUA, 3PCC

| Scenario | What it shows |
|---|---|
| Call_transfer_client.txt ↔ Call_transfer_server.txt | blind transfer (REFER/202/NOTIFY sipfrag), the server saves dialog identifiers and sends its own INVITE/BYE/NOTIFY with `cmd_setRemote` |
| Call_brokering_b2bua_server.txt | registrar plus back-to-back call broker: `save(SDP)`, `save(REMOTE_IP_PORT)`, `cmd_setRemote=[$rem1]` |
| Attended_transfer_pbx_client.txt, Attended_transfer_phones_client.txt ↔ Attended_transfer_target_server.txt | attended transfer (lab scenarios with fixed addresses) |

## Load control

| Scenario | What it shows |
|---|---|
| Load_gradual_increase_client.txt | raises concurrent calls step by step with `[CCnt]` conditions and `cmd_Spec=setCC([$n])` |

Files named `Cap_*.txt` or `pcap_trace.txt` are made by Trace to Scenario from a capture; they are the
user's own and not examples of hand-written style.
