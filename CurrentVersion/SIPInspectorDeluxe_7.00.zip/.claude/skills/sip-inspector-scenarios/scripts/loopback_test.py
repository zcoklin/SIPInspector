#!/usr/bin/env python3
"""
Plays a server scenario and a client scenario against each other on this computer (127.0.0.1) with the
SIP Inspector CLI, and says whether both sides got through.

    loopback_test.py --root <SIP Inspector folder> --server Reg_server.txt --client Reg_client.txt
    loopback_test.py --root . --server s.txt --client c.txt --calls 5 --pause-ms 2000 --transport TCP
    loopback_test.py --root . --cli "java -jar SIPInspector.jar" --server s.txt --client c.txt

The server starts first (it waits for calls), then the client makes --calls calls. The run passes when
the client CLI ends with exit code 0 and "SUCCESS", and neither side reports unexpected messages.
The CLI's own SIP/SDP checks are printed too. Scenario names without a folder are looked up in
<root>/scenarios. --pause-ms caps every cmd_Pause and pcap duration (on copies; the files are not
changed) for a quick run.

Needs the SIP Inspector CLI with a registered license. Python 3.6+, standard library only.
Exit code: 0 pass, 1 fail, 2 the run could not be started.
"""

import argparse
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import tempfile
import time


def find_cli(root, given):
    if given:
        return shlex.split(given, posix=(os.name != "nt"))
    for name in ("SIPInspDlxCLI.exe", "SIPInspDlx"):
        p = os.path.join(root, name)
        if os.path.isfile(p):
            return [p]
        w = shutil.which(name)
        if w:
            return [w]
    jars = [f for f in os.listdir(root) if f.lower().endswith(".jar")]
    for sub in ("dist",):
        d = os.path.join(root, sub)
        if os.path.isdir(d):
            jars += [os.path.join(sub, f) for f in os.listdir(d) if f.lower().endswith(".jar")]
    if jars and shutil.which("java"):
        lib = os.path.join(root, "lib")
        cp = os.path.join(root, jars[0])
        if os.path.isdir(lib):
            cp += os.pathsep + os.path.join(lib, "*")
        return ["java", "-Djava.awt.headless=true", "-cp", cp, "sipinspector.Main"]
    return None


def resolve(root, name):
    if os.path.isfile(name):
        return os.path.abspath(name)
    p = os.path.join(root, "scenarios", name)
    if os.path.isfile(p):
        return p
    sys.exit("scenario not found: %s (also looked in %s)" % (name, os.path.join(root, "scenarios")))


def capped_copy(path, workdir, cap):
    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()
    if cap is not None:
        text = re.sub(r"(?m)^(cmd_Pause=)(\d+)", lambda m: m.group(1) + str(min(int(m.group(2)), cap)), text)
        text = re.sub(r";duration=(\d+)", lambda m: ";duration=" + str(min(int(m.group(1)), cap)), text)
    out = os.path.join(workdir, os.path.basename(path))
    with open(out, "w", encoding="utf-8") as f:
        f.write(text)
    return out


def start(cmd, cwd, out_path):
    out = open(out_path, "w")
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = subprocess.CREATE_NEW_PROCESS_GROUP
    return subprocess.Popen(cmd, cwd=cwd, stdout=out, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, **kw), out


def stop(proc):
    if proc.poll() is not None:
        return
    try:
        if os.name == "nt":
            proc.send_signal(signal.CTRL_BREAK_EVENT)
        else:
            proc.send_signal(signal.SIGTERM)  # the CLI prints its summary on SIGTERM
        proc.wait(15)
    except Exception:
        proc.kill()
        proc.wait()


def read(path):
    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


# the last result line of a CLI run, as test/scenario_test.py of the program reads it
RESULT = re.compile(r"(SUCCESS|FAILURE|TERMINATED)!?(?: - Unexpected: (.*))?\s*$")


def judge(text, code, client):
    if re.search(r"Unregistered version|NOT REGISTERED", text, re.I):
        return ["the CLI is not registered on this computer (license / Machine-ID): nothing was tested"]
    result, unexpected = None, ""
    for line in reversed([l.strip() for l in re.split(r"[\r\n\b]", text) if l.strip()]):
        m = RESULT.search(line)
        if m:
            result, unexpected = m.group(1), (m.group(2) or "").strip()
            break
    problems = []
    if result is None:
        problems.append("no result line in the output")
    elif client and result != "SUCCESS":
        problems.append("ended with " + result)
    elif not client and result == "FAILURE":
        problems.append("ended with FAILURE")
    if client and code not in (0, None):
        problems.append("exit code %s" % code)
    if unexpected:
        problems.append("unexpected messages: " + unexpected[:300])
    return problems


def main():
    ap = argparse.ArgumentParser(description="Play a server and a client scenario against each other on 127.0.0.1.")
    ap.add_argument("--root", default=".", help="SIP Inspector folder (has scenarios/, pcap/); the CLI runs there")
    ap.add_argument("--server", required=True, help="server-side scenario (starts by receiving)")
    ap.add_argument("--client", required=True, help="client-side scenario (starts by sending)")
    ap.add_argument("--cli", help='how to start the CLI, e.g. "SIPInspDlx" or "java -jar SIPInspector.jar"')
    ap.add_argument("--calls", type=int, default=1, help="calls the client makes (default 1)")
    ap.add_argument("--concurrent", type=int, default=1, help="calls at the same time (default 1)")
    ap.add_argument("--cps", default="1", help="calls per second (default 1)")
    ap.add_argument("--transport", default="UDP", choices=["UDP", "TCP", "TLS", "WS", "WSS"])
    ap.add_argument("--pause-ms", type=int, help="cap every pause and pcap duration to this many ms")
    ap.add_argument("--server-port", type=int, default=5370)
    ap.add_argument("--client-port", type=int, default=5380)
    ap.add_argument("--uf", default="1000", help="client From user")
    ap.add_argument("--ut", default="2000", help="client To user")
    ap.add_argument("--au", default="1000", help="auth user")
    ap.add_argument("--ap", default="secret", help="auth password")
    ap.add_argument("--values", help="values file for the client (-fv)")
    ap.add_argument("--timeout", type=int, default=0, help="seconds the client may take (default: from the pauses)")
    ap.add_argument("--startup", type=float, default=3, help="seconds the server gets to start (default 3)")
    ap.add_argument("--keep", action="store_true", help="keep the work folder with the outputs")
    args = ap.parse_args()

    root = os.path.abspath(args.root)
    cli = find_cli(root, args.cli)
    if not cli:
        print("cannot find the SIP Inspector CLI in %s or on the PATH; give it with --cli" % root)
        sys.exit(2)
    work = tempfile.mkdtemp(prefix="si_loopback_")
    server = capped_copy(resolve(root, args.server), work, args.pause_ms)
    client = capped_copy(resolve(root, args.client), work, args.pause_ms)

    def total_pause(path):
        t = read(path)
        ms = sum(int(x) for x in re.findall(r"(?m)^cmd_Pause=(\d+)", t))
        ms += sum(int(x) for x in re.findall(r";duration=(\d+)", t))
        return ms / 1000.0

    waves = -(-args.calls // max(args.concurrent, 1))
    timeout = args.timeout or int((total_pause(client) + 5) * waves + args.calls / max(float(args.cps), 0.1) + 30)
    common = ["-t", args.transport, "-np", "-d", "ERROR"]

    s_cmd = cli + common + ["-lip", "127.0.0.1", "-lp", str(args.server_port), "-lrtp", "7300", "-fs", server,
                            "-mc", str(args.concurrent + 10), "-tc", str(args.calls), "-cps", "1", "-to", str(timeout + 30)]
    c_cmd = cli + common + ["-lip", "127.0.0.1", "-lp", str(args.client_port), "-lrtp", "6300",
                            "-rip", "127.0.0.1", "-rp", str(args.server_port), "-fs", client,
                            "-uf", args.uf, "-ut", args.ut, "-au", args.au, "-ap", args.ap,
                            "-cps", str(args.cps), "-mc", str(args.concurrent), "-tc", str(args.calls), "-to", str(timeout)]
    if args.values:
        c_cmd += ["-fv", os.path.abspath(args.values)]

    print("server: %s" % " ".join(s_cmd))
    print("client: %s" % " ".join(c_cmd))
    s_out, c_out = os.path.join(work, "server.out"), os.path.join(work, "client.out")
    sp, sf = start(s_cmd, root, s_out)
    cp = cf = None
    try:
        time.sleep(args.startup)
        if sp.poll() is not None:
            sf.close()
            text = read(s_out)
            if re.search(r"Unregistered version|NOT REGISTERED", text, re.I):
                print("the SIP Inspector CLI is not registered on this computer (license / Machine-ID), so nothing can be "
                      "tested here:\n" + text[-800:])
            else:
                print("the server ended at once (exit code %s):\n%s" % (sp.returncode, text[-2000:]))
            sys.exit(2)
        cp, cf = start(c_cmd, root, c_out)
        try:
            cp.wait(timeout + 30)
        except subprocess.TimeoutExpired:
            stop(cp)
        # a server that ends the call itself (sends the BYE after its pause) may still be busy
        deadline = time.time() + min(total_pause(server), 60) + 3
        while sp.poll() is None and time.time() < deadline:
            time.sleep(0.2)
    finally:
        if cp is not None:
            stop(cp)
        stop(sp)
        sf.close()
        if cf:
            cf.close()

    s_text, c_text = read(s_out), read(c_out)
    problems = ["client: " + p for p in judge(c_text, cp.returncode if cp else None, True)]
    problems += ["server: " + p for p in judge(s_text, None, False)]
    for name, text in (("client", c_text), ("server", s_text)):
        m = re.search(r"(?m)^.*sip/sdp checks:.*$", text)
        if m:
            print("%s %s" % (name, m.group(0).strip()))
    if problems:
        print("\nFAIL")
        for p in dict.fromkeys(problems):
            print("  " + p)
        for name, text in (("client", c_text), ("server", s_text)):
            print("\n---- last lines of the %s output ----\n%s" % (name, "\n".join(text.strip().splitlines()[-30:])))
    else:
        print("\nPASS: %d call(s), client exit code 0, no unexpected messages" % args.calls)
    if args.keep or problems:
        print("\noutputs kept in %s" % work)
    else:
        shutil.rmtree(work, ignore_errors=True)
    sys.exit(1 if problems else 0)


if __name__ == "__main__":
    main()
