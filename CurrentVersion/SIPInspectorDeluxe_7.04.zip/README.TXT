 *******************************************************************************
 *                                                                             *
 *  LICENSE AGREEMENT:                                                         *
 *                                                                             *
 *  SIP Inspector is paid for software and MUST not be used without a valid    *
 *  license. For more information have a look at License.txt file.             *
 *                                                                             *
 *  Editions: Standard, Pro and Unlimited. A license is for one computer.      *
 *  Buy one:           https://www.sipinspector.com/purchase                   *
 *  Try it for 5 days: https://www.sipinspector.com/trial                      *
 *  The serial number comes by email for the Machine-ID that the first screen  *
 *  of the program shows.                                                      *
 *                                                                             *
 *  To report problems related with the tool, for licensing inquiries please   *
 *                                                                             *
 *                       support@sipinspector.com                              *
 *                                                                             *
 *******************************************************************************
 *                                                                             *
Visit SIP Inspector web site for more details: https://www.sipinspector.com

Writing scenarios with Claude
  The program comes with a skill for Claude, the AI assistant of Anthropic (an account at
  claude.ai is needed; SIP Inspector sends nothing to it). With it Claude writes scenarios from a
  description of the call, writes both sides and plays them against each other on this computer,
  makes a scenario from a Wireshark capture, explains why a run failed and fixes the scenario.
  * Claude Code: the skill is in .claude/skills/sip-inspector-scenarios. Open a terminal in this
    folder, start claude and describe the call.
  * claude.ai: upload sip-inspector-scenarios.skill under Settings/Capabilities/Skills (code
    execution on) and attach the closest sample scenario to the chat.
  See the chapter Writing scenarios with Claude in the manual.
Release notes
  The notes of every release are in the manual, chapter Release notes, and on the web site:
  https://www.sipinspector.com/docs/release-notes-7-04
  Releases of version 6: https://www.sipinspector.com/release-6-notes
