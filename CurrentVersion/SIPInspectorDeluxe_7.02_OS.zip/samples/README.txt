Samples
=======

reports/   The reports of two real runs, as -report (CSV), -html, -junit (XML) and -json write them.

  passed_run.*   scenarios/Reg_call_client.txt against Reg_call_server.txt: 10 calls, 2 per second,
                 at most 5 at a time, with the gate asr>=99,p95<=300,mos>=4.0,problems==0.
                 Result PASS, exit code 0.

  failed_run.*   scenarios/Call_speech_dials_asserts_client.txt against a server that answers with
                 G.722, a codec the client did not offer: 3 calls. The assertion
                 "body contains PCMU" fails, so every call is dropped at step 8, and the SIP/SDP
                 checks report the answer. Result FAIL, exit code 1. The HTML report ends with the
                 call flow of the first call that failed.

  Made with:
    SIPInspDlx -fs scenarios/Reg_call_client.txt -rip <server> -tc 10 -cps 2 -mc 5 -np \
               -gate "asr>=99,p95<=300,mos>=4.0,problems==0" \
               -report passed_run.csv -html passed_run.html -junit passed_run.xml -json passed_run.json

api/       si_suite.py: a regression suite run through the service (POST /run). It starts every
           test, waits for its end, saves its JUnit report (test1.xml ...) and ends with exit
           code 1 when a test failed. Python 3, nothing to install. Set API, TOKEN and REMOTE at
           the top. See the manual, chapter The REST API step by step.
