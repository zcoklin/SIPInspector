#!/usr/bin/env python3
"""A regression suite on a SIP Inspector service, with a JUnit report of every test."""
import json, sys, time, urllib.error, urllib.request

# the calling service: SIPInspDlx -api 8082 -apiToken s3cret-token ...
API = "http://127.0.0.1:8082"
TOKEN = "s3cret-token"
REMOTE = {"remote": "127.0.0.1", "remotePort": 5070}   # the device under test

TESTS = [
    {"scenario": "Reg_call_client.txt", "totalCalls": 4, "cps": 2,
     "gate": "asr>=99,mos>=4.0"},
    {"scenario": "Reg_call_client.txt", "totalCalls": 9, "cps": 3, "maxConcurrent": 3,
     "gate": "asr>=99,p95<=300"},
    {"scenario": "Reg_call_client.txt", "totalCalls": 4, "cps": 2, "gate": "p95<=5"},
]


def call(method, path, body=None, raw=False):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(API + path, method=method, data=data,
                                 headers={"Authorization": "Bearer " + TOKEN})
    try:
        with urllib.request.urlopen(req) as r:
            text = r.read().decode()
    except urllib.error.HTTPError as e:      # 400, 404, 409: the answer says why
        text = e.read().decode()
    return text if raw else json.loads(text)


failed = 0
for test in TESTS:
    run = call("POST", "/run", dict(test, **REMOTE))
    if "error" in run:
        print("not started:", run["error"])
        failed += 1
        continue
    n = run["run"]
    while True:                               # one run at a time: wait for its end
        status = call("GET", "/runs/%d" % n)
        if status["state"] in ("finished", "failed"):
            break
        time.sleep(1)
    with open("test%d.xml" % n, "w") as f:
        f.write(call("GET", "/report?run=%d&format=junit" % n, raw=True))
    print("run %d  %-20s %-20s %s  exit %s  %.1f s" % (n, test["scenario"], test.get("gate", ""),
                                                      status["result"], status["exitCode"],
                                                      status["seconds"]))
    failed += status["exitCode"] != 0
sys.exit(1 if failed else 0)
