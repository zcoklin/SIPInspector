---
name: sip-inspector-scenarios
description: Write, fix, explain and test SIP Inspector scenario files (the plain-text .txt files of arrow-separated SIP messages and commands that SIP Inspector Pro runs as a SIP client or server). Use this skill whenever the user wants a SIP Inspector scenario, a SIP test call flow, a client or server side for SIP Inspector, a counterpart scenario, or asks to change, debug, validate or explain a file from the SIP Inspector scenarios folder - also when they only describe a SIP call flow (REGISTER, INVITE, PRACK, re-INVITE, REFER, SUBSCRIBE/NOTIFY, digest auth, DTMF, RTP, SRTP, video, load tests) and SIP Inspector is the tool they test with, even if they never say "scenario".
---

# SIP Inspector scenarios

SIP Inspector Pro plays a SIP call flow from a plain-text **scenario file**. The same file runs in the
GUI (File/Load Scenario) and in the CLI (`SIPInspDlx -fs file.txt`, on Windows `SIPInspDlxCLI.exe`).
Your job is to turn what the user describes into a scenario that loads, runs and does what they meant,
and to show them it works.

## Workflow

1. **Understand the call flow.** Work out the role (client: the scenario starts by sending; server:
   it starts by receiving), the messages in order, which ones may or may not come (optional), media
   (none, pcap, live speech, echo, DTMF, video, SRTP), authentication, and whether a values file or
   load settings are involved. Ask only when a choice changes the flow and cannot be defaulted
   sensibly; otherwise pick the common behaviour and say what you assumed.
2. **Start from the closest sample.** Find the SIP Inspector folder (it has `scenarios/`, `pcap/`,
   `values/`). Read `references/samples.md` to pick the sample(s) closest to the request, then read
   them. Copy their messages and adapt them rather than writing headers from memory. The samples are
   tested against each other, so their Via/From/To/CSeq/tag idioms are known to work with the program.
3. **Write the scenario** following the rules below and `references/format.md` (every entry type,
   keyword, condition, variable and assertion). Start the file with the header comment.
4. **Check it** with the bundled checker (Python 3, no packages):
   `python3 <skill-dir>/scripts/check_scenario.py path/to/scenario.txt`
   Fix every ERROR. Read every WARN and fix it or be able to say why it is fine. Run it again.
5. **Test it on this computer when you can.** When the scenario has a counterpart (a sample or one you
   write), play them against each other on 127.0.0.1 with
   `python3 <skill-dir>/scripts/loopback_test.py --root <SIP Inspector folder> --server S.txt --client C.txt`
   (see "Testing" below). A pass is the strongest evidence you can give the user.
6. **Hand it over:** where the file is, the call flow in a few lines, assumptions you made, and the
   exact CLI command (or GUI steps) to run it against their system with their addresses and users.

Save new scenarios in the `scenarios/` folder of the installation unless the user says otherwise.
Use a descriptive file name in the style of the samples (`Reg_call_client.txt`, `PRACK_server.txt`).
Write files with LF line endings.

## The file in one screen

```
////////////////////////////////////////////////////////////////////////////////
// Client: <one line: what it does>
//
// Counterpart of <server scenario>.
//
// <a few lines of why / what is special>
//
// SIP Messages
//  ---> INVITE
//  <--- 100 Trying (optional)
//  <--- 180 Ringing
//  <--- 200 OK
//  ---> ACK
//  ---- play test.pcap, pause 15 s
//  ---> BYE
//  <--- 200 OK
////////////////////////////////////////////////////////////////////////////////

---------->
INVITE sip:[toUsername]@[remote_ip]:[remote_port] SIP/2.0
Via: SIP/2.0/[transport] [local_ip]:[local_port];branch=[branch]
...
Content-Length: [len]

v=0
...

<----------*
100 Trying

<----------
180 Ringing

----------
cmd_Pause=15000
```

- Everything before the first separator line is the header comment; `//` lines are comments anywhere.
  Every sample starts with the header comment in the style above. Write one too: users rely on it as the
  documentation of the scenario.
- `---------->` sends a message, `<----------` waits for one, a `*` right after the arrow makes the entry
  optional, `;retrans` after the arrow (and after a `*`) turns on RFC 3261 retransmission
  over UDP for that message: `---------->;retrans` sends it again until it is answered, `<----------;retrans`
  answers copies of it as before (see references/format.md). `;ReTxCnt=N` is the earlier format: never write it. `----------` alone starts any other entry.
- **One entry per block.** The program recognises a block by its first known line, so a second command
  in the same block is lost. Give every command its own `----------` line.
- An **incoming** entry is only its start line: `INVITE`, `ACK`, `BYE`, `180 Ringing`, `200 OK`. It
  matches on the method or the status code; headers are not needed.
- An **outgoing** entry is the whole message as it goes on the wire, with keywords where a value changes
  per call. After the headers comes one empty line, then the body if there is one. A message without a
  body ends with `Content-Length: 0` and an empty line.

## Rules that keep a scenario working

These are the mistakes that make a scenario fail on the wire or get rejected by the far end:

- **Use keywords, not literal addresses or users.** `[local_ip]`, `[local_port]`, `[remote_ip]`,
  `[remote_port]`, `[transport]`, `[fromUsername]`, `[toUsername]`, `[media_port]`, `[local_ip_sdp]`,
  `[IP_ver]`. Then the same file works on any network and with the CLI options. A keyword the program does
  not know is sent as written, so spell them exactly as in `references/format.md`.
- **Always `Content-Length: [len]`** when there is a body. The program counts the bytes; a hand count is
  wrong as soon as a keyword is replaced.
- **CSeq:** `[cseq+1]` on each new request of the dialog (it also advances the counter), `[cseq]` on an
  ACK or CANCEL (same number as the INVITE it belongs to) and on the very first request if you want it to
  start from the current value. The method after the number must be the request's method.
- **Tags:** the client's From has `;tag=[call_number]` (or a fixed tag, as the REGISTER samples do). An
  in-dialog request from the client (ACK for a 2xx, BYE, re-INVITE, PRACK) has
  `To: <...>;[peer_tag_param]`. A server builds responses from the request with `[last_Via:]`,
  `[last_From:]`, `[last_To:]`, `[last_Call-ID:]`, `[last_CSeq:]`, and its first non-100 response of a
  dialog adds `;tag=[call_number]` after `[last_To:]`. A 100 Trying has no To tag.
- **Call-ID:** `[call_number].[run_tag]@[local_ip]` for a dialog the scenario starts, the same in all its messages.
  `[run_tag]` is new for each run, so the Call-ID is not one an earlier run used.
  Between dialogs put a `cmd_NewDialog` entry (register, then call; register, then wait for calls).
- **Max-Forwards: 70** in every request you send. `User-Agent: SIPInspector_v_[ver]` and a `Contact` as in
  the samples.
- **Media needs time.** `cmd_PlayPcap=<file>` and `cmd_RTPSpeech` start the media and the scenario moves
  on at once. Put a `cmd_Pause=<ms>` after them (or wait for the far end's BYE), otherwise the BYE goes out
  immediately and no audio is heard. `cmd_PlayPcap=<file>;duration=<ms>` is different: it holds the call
  for that long by itself.
- **SDP:** take it from a sample. The `m=` line uses `[media_port]`, `o=`/`c=` use `IN [IP_ver]
  [local_ip_sdp]`, every dynamic payload type (96-127) has an `a=rtpmap`, SRTP uses `RTP/SAVP` with an
  `a=crypto` line. Codecs the program can stream: PCMU (0), PCMA (8), G.729 (18), telephone-event
  for DTMF; H.264 video via `[video_port]`.
- **Optional entries** cover the things the far end may or may not do: `<----------*` for a 100 Trying, a
  401/407 challenge, an 18x. An optional outgoing message (`---------->*`) is sent only when the optional
  message before it came in - that is how "re-send REGISTER with credentials only if challenged" works.
- **Retransmission (`;retrans`), on by default for UDP:** real phones, PBXs and proxies send a message
  again when its answer is late or lost, and without `;retrans` each copy fails the step as unexpected.
  So in a scenario that runs over UDP (the default), put `;retrans` after the arrow (after a `*` if there
  is one) of:
  - every request you **send** except ACK (INVITE, re-INVITE, BYE, CANCEL, REGISTER, SUBSCRIBE, NOTIFY,
    REFER, OPTIONS, MESSAGE, INFO, UPDATE, PRACK), and every **final response you send to an INVITE**
    (200, 486, 603 ...): they are sent again until answered (the ACK answers a final response);
  - the same messages where you **receive** them (`<----------;retrans` on an incoming INVITE, BYE,
    REGISTER, NOTIFY ..., and on the final response to an INVITE you sent): a copy is answered again.
  Never on an ACK, a provisional response (100, 180, 183) or a response to a request other than INVITE.
  The two sides of a pair are marked the same way. Leave it out only when the user wants exact messages
  (each sent once, a copy counted as unexpected) or the scenario probes the far end (a port scan).
  T1 and T2 are run settings (`-t1`, `-t2`), never written in the file; over TCP and TLS `;retrans` does
  nothing, so it is harmless to keep. Mark the messages in the header comment too (`//  ---> INVITE ;retrans`).
- **Authentication:** after a 401 or 407, send the request again with
  `Authorization: [authentication username=[authUsername]; password=[authPassword];]` (or
  `Proxy-Authorization:` for 407) and `[cseq+1]`. A 407/401 to an INVITE must be acknowledged with an ACK
  (`[cseq]`, same branch as the INVITE) before the new INVITE.
- **Branching:** a `condition=if (Resp == 404) goto end` or `condition=if (REQ == NOTIFY) goto x` is
  tested against the next message that comes in, so place it where the scenario waits for that message.
  When it holds, the condition takes the message and the call goes on at the label, so the label can stand
  right before the entry that reacts to it (Reg_auth_call_advanced_client.txt branches on 200/401/407
  this way). When it does not hold, the message is matched against the following entries as usual.
  Every `goto` target must exist as `label=...`. Conditions on variables (`[CCnt]`, `$var`) are tested
  where they stand.
- **Pairs:** if the user tests against SIP Inspector itself, or asks for both sides, write the counterpart
  as well. Each side's optional entries must match what the other side really sends, and its `;retrans`
  messages what the other side sends with `;retrans`.

## Testing

`scripts/loopback_test.py` starts the server scenario, then the client scenario against it on
127.0.0.1, waits for the client to finish and reports both results (exit code, unexpected messages, the
SIP/SDP checks the program does itself). It needs the SIP Inspector CLI and a registered license on this
computer (if the CLI says it is not registered, tell the user and rely on the checker); `--cli` tells it how to start the CLI if it is not `SIPInspDlx`/`SIPInspDlxCLI.exe` in the
folder or on the PATH (for example `--cli "/opt/SIPInspector/SIPInspDlx"`, on Windows `--cli "C:\SI\SIPInspDlxCLI.exe"`). `--pause-ms 2000` shortens the
pauses for a quick run. Run `--help` for the options.

When there is no counterpart (the user's real PBX is the other side), say so and give the command to
run it there; the checker plus the program's own checks during the run (`sip/sdp checks:` in the CLI
summary, Tools/Validate Scenario in the GUI) are then the evidence.

If a run fails, read the output the script prints: an "unexpected message" means the flow of one side
does not match what the other sent (an entry that should be optional, a missing entry, wrong order); a
call that does not finish usually waits for a message the other side never sends.

## Running it for real

Give the user a command of this shape, with their values:

```
SIPInspDlx -lip <local IP> -rip <PBX IP> -rp 5060 -fs scenarios/<file>.txt \
           -uf <from user> -ut <to user> -au <auth user> -ap <password> -tc 1
```

`-t TCP|TLS|WS|WSS` for another transport, `-cps / -mc / -tc` for load, `-fv values/file.txt` for a
values file, `-html report.html` for a report. On Windows the command is `SIPInspDlxCLI.exe`. In the GUI:
File/Load Scenario, fill in the addresses and account fields, Run.

## Reference files

- `references/format.md` - every entry type, keyword, condition, variable, assertion and the values file
  format. Read it before using anything beyond plain messages and pauses.
- `references/samples.md` - the sample scenarios, what each shows and which pairs belong together.
