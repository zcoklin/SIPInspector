#!/usr/bin/env python3
"""
Checks a SIP Inspector scenario file before it is run.

    check_scenario.py scenario.txt [more.txt ...] [--root SIP_INSPECTOR_FOLDER] [--outline]

It reads the file the way SIP Inspector does (separator lines, one entry per block) and reports
  ERROR  the program would ignore or refuse the entry, or a call cannot get through it
  WARN   likely to be wrong on the wire or rejected by the far end
  INFO   worth knowing
--outline prints the call flow in the style of the scenario header comments.
--root is the SIP Inspector folder: pcap paths are then checked to exist.

Exit code: 0 no errors, 1 errors, 2 the file cannot be read. Python 3.6+, standard library only.
"""

import argparse
import os
import re
import sys

SEND = re.compile(r"^---------->(\*)?\s*(?:;\s*(retrans)\b|;ReTxCnt=(\S*))?\s*$", re.I)
RECV = re.compile(r"^<----------(\*)?\s*(?:;\s*(retrans)\b)?\s*$", re.I)
OTHER = re.compile(r"^----------\s*$")
ANY_SEP = re.compile(r"^(?:---------->|<----------|----------)")

KNOWN_KEYWORDS = {
    "local_ip", "local_ip_sdp", "local_port", "remote_ip", "remote_port", "transport", "IP_ver",
    "media_port", "video_port", "fromUsername", "toUsername", "authUsername", "authPassword",
    "branch", "call_number", "run_tag", "CCnt", "cseq", "peer_tag_param", "len", "ver", "hex", "/hex",
    "no_\\r\\n",
}
KEYWORD_PATTERNS = [
    re.compile(r"^cseq[+-]\d+$"),
    re.compile(r"^field\d+$"),
    re.compile(r"^field:.+$"),
    re.compile(r"^(val_)?last_[A-Za-z0-9-]+:$"),
    re.compile(r"^\$[A-Za-z_][A-Za-z0-9_]*([+-]\d+)?$"),
    re.compile(r"^authentication\s+username=.*;\s*password=.*;?\s*$", re.S),
]
METHODS = {"INVITE", "ACK", "BYE", "CANCEL", "REGISTER", "OPTIONS", "PRACK", "SUBSCRIBE", "NOTIFY",
           "PUBLISH", "INFO", "REFER", "MESSAGE", "UPDATE"}
DIALOG_STARTERS = {"INVITE", "REGISTER", "SUBSCRIBE", "OPTIONS", "MESSAGE", "PUBLISH", "REFER", "NOTIFY", "INFO"}
COMMANDS = [  # (prefix, kind) in the order SIP Inspector tries them
    ("cmd_Pause=", "pause"), ("cmd_PlayPcap=", "pcap"), ("cmd_RTPEcho", "echo"), ("cmd_RTPSpeech", "speech"),
    ("cmd_DialDigits=", "digits"), ("set_Variable=", "setvar"), ("assert=", "assert"), ("=save(", "save"),
    ("=rand[", "rand"), ("label=", "label"), ("goto=", "goto"), ("condition=", "condition"),
    ("cmd_setRemote=", "remote"), ("cmd_NewDialog", "newdialog"), ("waitRTP", "waitrtp"),
    ("waitVideo", "waitvideo"), ("cmd_Spec", "spec"), ("cmd_setMediaPort", "mediaport"),
]
CONDITION = re.compile(r"^if\s*\(\s*([^\s/%]+?)\s*(?:([/%])\s*(\d+))?\s+(==|!=|<=|>=|<|>|has)\s+(.+?)\s*\)\s*goto\s+(\S+)\s*$")
ASSERT_RTP = re.compile(r"^rtp\s+(packets|loss|jitter|mos)\s*(<=|>=|==|<|>)\s*-?\d+(\.\d+)?$", re.I)


class Entry:
    def __init__(self, number, line, sep, lines):
        self.number = number      # 1-based entry number, as the GUI counts them
        self.line = line          # line number of the separator in the file
        self.sep = sep
        self.lines = lines        # the lines after the separator, comments removed
        self.kind = None          # send, recv, or a command kind
        self.optional = False
        self.retrans = False
        self.text = ""            # the recognised command line
        self.start = ""           # start line of a SIP message

    def title(self):
        if self.kind == "send":
            return "---> " + self.start
        if self.kind == "recv":
            return "<--- " + self.start
        return "---- " + (self.text or (self.lines[0] if self.lines else "(empty)"))


class Report:
    def __init__(self, path):
        self.path = path
        self.items = []

    def add(self, level, entry, msg):
        where = "entry %d (line %d, %s)" % (entry.number, entry.line, entry.title()[:60]) if entry else "file"
        self.items.append((entry.number if entry else 0, level, where, msg))

    def count(self, level):
        return sum(1 for i in self.items if i[1] == level)


def split_entries(text):
    raw = text.split("\n")
    lines = [l[:-1] if l.endswith("\r") else l for l in raw]
    entries = []
    current = None
    header = []
    for idx, line in enumerate(lines, 1):
        if ANY_SEP.match(line):
            current = Entry(len(entries) + 1, idx, line.rstrip(), [])
            entries.append(current)
        elif current is None:
            header.append(line)
        elif line.startswith("//"):
            continue
        else:
            current.lines.append(line)
    return header, entries


def keywords_in(s):
    """Keywords in a text, with nesting ([authentication username=[authUsername]; ...]) and [[ escapes."""
    found = []
    i = 0
    n = len(s)
    while i < n:
        if s[i] == "[":
            if i + 1 < n and s[i + 1] == "[":
                i += 2
                continue
            depth = 0
            j = i
            while j < n:
                if s[j] == "[":
                    depth += 1
                elif s[j] == "]":
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            if j >= n:
                found.append((s[i + 1:], False))
                break
            inner = s[i + 1:j]
            found.append((inner, True))
            for k in keywords_in(inner):
                if k[0] != inner:
                    found.append(k)
            i = j + 1
        else:
            i += 1
    return found


def known_keyword(k):
    return k in KNOWN_KEYWORDS or any(p.match(k) for p in KEYWORD_PATTERNS)


def classify(e, rep):
    m = SEND.match(e.sep)
    if m:
        e.kind = "send"
        e.optional = bool(m.group(1))
        e.retrans = m.group(2) is not None
        if m.group(3) is not None:
            # the earlier format: the program reads it as ;retrans and saves ;retrans
            rep.add("WARN", e, ";ReTxCnt=%s is the earlier format: write ;retrans (RFC 3261 timers with the T1 and T2 of the run)" % m.group(3))
            e.retrans = m.group(3).isdigit() and int(m.group(3)) > 0
    elif RECV.match(e.sep):
        e.kind = "recv"
        e.optional = bool(RECV.match(e.sep).group(1))
        e.retrans = RECV.match(e.sep).group(2) is not None
    elif OTHER.match(e.sep):
        e.kind = None
    else:
        rep.add("ERROR", e, "separator line '%s' is not one SIP Inspector reads: use ---------->, ---------->*, "
                            "---------->;retrans, <----------, <----------*, <----------;retrans or ----------" % e.sep)
        e.kind = "bad"
        return
    if e.kind in ("send", "recv"):
        body = [l for l in e.lines]
        while body and not body[0].strip():
            body.pop(0)
        if not body:
            rep.add("ERROR", e, "a message entry without a message")
            e.kind = "bad"
            return
        e.start = body[0].strip()
        e.lines = body
        if e.retrans:
            # RFC 3261 sends again only a request other than ACK and a final response (to an INVITE)
            status = re.match(r"^(?:SIP/2\.0\s+)?(\d{3})\b", e.start)
            method = None if status else e.start.split()[0].upper()
            if method == "ACK" or (status and status.group(1).startswith("1")):
                rep.add("WARN", e, ";retrans on %s has no effect: RFC 3261 sends again only a request other than ACK, or a final response to an INVITE"
                        % (method or status.group(1)))
        return
    # a command block: the first line any entry type knows
    meaningful = [l for l in e.lines if l.strip()]
    for line in meaningful:
        for prefix, kind in COMMANDS:
            hit = line.strip().startswith(prefix) if not prefix.startswith("=") else prefix in line
            if hit:
                e.kind = kind
                e.text = line.strip()
                break
        if e.kind:
            break
    if not e.kind:
        rep.add("ERROR", e, "the block is not an entry SIP Inspector knows, it is ignored: %s"
                % (meaningful[0][:70] if meaningful else "(empty block)"))
        e.kind = "bad"
        return
    rest = [l for l in meaningful if l.strip() != e.text]
    if rest:
        if ANY_SEP.match(rest[0]) is None and re.match(r"^[A-Z]+ \S+ SIP/2\.0|^SIP/2\.0 \d{3}", rest[0]):
            rep.add("ERROR", e, "a SIP message under a ---------- separator: use ----------> to send or <---------- to receive")
        else:
            rep.add("ERROR", e, "more than one line in the block; only '%s' is used, '%s' is lost. Give it its own ---------- line"
                    % (e.text[:40], rest[0].strip()[:40]))


def parse_message(lines):
    """Start line, headers (lower-case name -> list of values), raw header lines and the body lines."""
    start = lines[0].strip()
    headers = {}
    hdr_lines = []
    body = []
    i = 1
    while i < len(lines) and lines[i].strip() != "":
        hdr_lines.append(lines[i])
        line = lines[i]
        low = line.lower()
        for m in re.finditer(r"\[last_([a-z0-9-]+):\]", low):
            if low.strip().startswith("[last_"):
                headers.setdefault(m.group(1), []).append(line.strip())
        c = line.find(":")
        if c > 0 and not line.lstrip().startswith("["):
            headers.setdefault(line[:c].strip().lower(), []).append(line[c + 1:].strip())
        i += 1
    i += 1
    body = lines[i:]
    while body and body[-1].strip() == "":
        body.pop()
    return start, headers, hdr_lines, body


SHORT = {"v": "via", "f": "from", "t": "to", "i": "call-id", "m": "contact", "l": "content-length", "c": "content-type"}


def hget(headers, name):
    vals = headers.get(name) or []
    for s, l in SHORT.items():
        if l == name:
            vals = vals + (headers.get(s) or [])
    return vals


def concrete(v):
    return "[" not in v


def has_tag(v):
    return re.search(r";\s*tag=", v, re.I) is not None or "[peer_tag_param]" in v


def check_sdp(e, body, rep):
    lines = [l.strip() for l in body if l.strip()]
    if not lines:
        rep.add("WARN", e, "Content-Type is application/sdp but there is no body")
        return
    if len(lines) == 1 and re.match(r"^\[\$\w+\]$", lines[0]):
        return  # a saved SDP sent as a variable
    if not lines[0].startswith("v="):
        rep.add("WARN", e, "SDP must start with v=")
    for t in ("o=", "s=", "t="):
        if not any(l.startswith(t) for l in lines):
            rep.add("WARN", e, "SDP has no %s line" % t)
    media = [i for i, l in enumerate(lines) if l.startswith("m=")]
    if not media:
        rep.add("WARN", e, "SDP has no m= line")
    session_c = any(l.startswith("c=") for l in lines[:media[0]] if media) if media else False
    for n, mi in enumerate(media):
        end = media[n + 1] if n + 1 < len(media) else len(lines)
        section = lines[mi:end]
        parts = lines[mi].split()
        if len(parts) < 4:
            rep.add("WARN", e, "SDP media line '%s' is incomplete" % lines[mi])
            continue
        if parts[1] not in ("[media_port]", "[video_port]") and not parts[1].isdigit():
            rep.add("WARN", e, "SDP media port '%s' is not [media_port]/[video_port] or a number" % parts[1])
        if parts[0] == "m=audio" and parts[1] == "[video_port]":
            rep.add("WARN", e, "audio stream on [video_port]")
        if parts[0] == "m=video" and parts[1] == "[media_port]":
            rep.add("WARN", e, "video stream on [media_port]: use [video_port]")
        if not session_c and not any(l.startswith("c=") for l in section):
            rep.add("WARN", e, "SDP stream '%s' has no c= line (and there is none at session level)" % lines[mi])
        maps = {re.match(r"a=rtpmap:(\d+)", l).group(1) for l in section if re.match(r"a=rtpmap:(\d+)", l)}
        for pt in parts[3:] if parts[1] != "0" else []:  # port 0: a rejected stream
            if pt.isdigit() and 96 <= int(pt) <= 127 and pt not in maps:
                rep.add("WARN", e, "dynamic payload type %s has no a=rtpmap" % pt)
        crypto = any(l.startswith("a=crypto") for l in section)
        if parts[2] == "RTP/SAVP" and not crypto:
            rep.add("WARN", e, "RTP/SAVP without an a=crypto line")
        if crypto and parts[2] != "RTP/SAVP":
            rep.add("WARN", e, "a=crypto in a stream that is not RTP/SAVP")
    for l in lines:
        if l.startswith(("o=", "c=")) and "[local_ip]" in l:
            rep.add("WARN", e, "use [local_ip_sdp] in SDP: [local_ip] has brackets around an IPv6 address")
            break


def check(path, root=None, outline=False):
    rep = Report(path)
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError as exc:
        print("%s: cannot read: %s" % (path, exc))
        return None
    text = data.decode("utf-8", errors="replace")
    if "�" in text:
        rep.add("WARN", None, "the file is not valid UTF-8")
    crlf = text.count("\r\n")
    if crlf and crlf != text.count("\n"):
        rep.add("INFO", None, "mixed CRLF and LF line endings (the program reads both)")
    header, entries = split_entries(text)
    if not entries:
        rep.add("ERROR", None, "no entries: a scenario needs separator lines (---------->, <----------, ----------)")
        return rep
    if not any(l.strip().startswith("//") for l in header):
        rep.add("INFO", None, "no header comment: the samples start with one that says what the scenario does, "
                              "its counterpart and its messages")

    for e in entries:
        classify(e, rep)

    labels = {}
    for e in entries:
        if e.kind == "label":
            name = e.text[len("label="):].strip()
            if not name:
                rep.add("ERROR", e, "label without a name")
            elif name in labels:
                rep.add("ERROR", e, "label '%s' is defined twice (entry %d too)" % (name, labels[name].number))
            else:
                labels[name] = e

    defined = {}   # variable -> entry number where it is set first
    for e in entries:
        name = None
        if e.kind == "setvar":
            parts = e.text[len("set_Variable="):].split(None, 1)
            name = parts[0] if parts else None
        elif e.kind in ("save", "rand"):
            name = re.split(r"=", e.text, 1)[0].strip()
        if name and name not in defined:
            defined[name] = e.number

    role = None
    for e in entries:
        if e.kind in ("send", "recv"):
            role = "client" if e.kind == "send" else "server"
            break

    # dialog state, reset by cmd_NewDialog
    call_id = None
    established = False    # a To tag exists in this dialog: a response with a tag was sent, or a response came in
    media_running = None   # entry that started media which is not yet given time
    waits = False

    for idx, e in enumerate(entries):
        nxt = entries[idx + 1] if idx + 1 < len(entries) else None
        if e.kind == "newdialog":
            call_id, established, media_running = None, False, None
            continue

        # keywords and variables, in every entry the program sends or uses
        if e.kind not in ("recv", "bad", None, "rand"):
            text = "\n".join(e.lines) if e.kind == "send" else e.text
            for kw, closed in keywords_in(text):
                if not closed:
                    rep.add("WARN", e, "'[' without a closing ']': '%s' (a literal [ is written [[)" % kw[:30])
                    continue
                if not known_keyword(kw):
                    rep.add("WARN", e, "unknown keyword [%s] is sent as written; check the spelling" % kw[:40])
                m = re.match(r"^\$([A-Za-z_][A-Za-z0-9_]*)", kw)
                if m:
                    v = m.group(1)
                    if v not in defined:
                        rep.add("WARN", e, "variable [$%s] is never set (set_Variable, =save(...), =rand[...])" % v)
                    elif defined[v] > e.number:
                        rep.add("WARN", e, "variable [$%s] is used before it is set (entry %d)" % (v, defined[v]))

        if e.kind == "recv":
            s = e.start
            if not (re.match(r"^\d{3}(\s|$)", s) or re.match(r"^SIP/2\.0 \d{3}", s) or re.match(r"^[A-Z][A-Za-z-]*(\s|$)", s)):
                rep.add("ERROR", e, "an incoming entry is a method (INVITE) or a status code (200 OK), not '%s'" % s[:40])
            if re.match(r"^(SIP/2\.0 )?(1[0-9][1-9]|1[1-9]0|[2-6]\d\d)(\s|$)", s):
                established = True
            if media_running and s.split()[0] in ("BYE", "CANCEL"):
                media_running = None
            waits = True

        if e.kind == "send":
            start, headers, hdr_lines, body = parse_message(e.lines)
            is_resp = start.startswith("SIP/2.0 ")
            req = re.match(r"^([A-Za-z]+)\s+\S+\s+SIP/2\.0\s*$", start)
            if not is_resp and not req:
                rep.add("ERROR", e, "an outgoing message needs a full start line: 'METHOD sip:... SIP/2.0' or 'SIP/2.0 200 OK'")
                continue
            if is_resp and not re.match(r"^SIP/2\.0 \d{3} ", start + " "):
                rep.add("ERROR", e, "response start line must be 'SIP/2.0 <code> <reason>'")
            method = req.group(1) if req else None
            status = start[8:11] if is_resp else None
            if method and method not in METHODS:
                rep.add("INFO", e, "custom method %s" % method)
            for name in ("via", "from", "to", "call-id", "cseq"):
                if not hget(headers, name):
                    rep.add("WARN", e, "no %s header (every SIP message needs Via, From, To, Call-ID and CSeq)" % name.title())
            if method and not headers.get("max-forwards"):
                rep.add("WARN", e, "a request needs Max-Forwards (RFC 3261 8.1.1.6): add 'Max-Forwards: 70'")
            frm = (hget(headers, "from") or [""])[0]
            if frm and "[last_from:]" not in frm.lower() and "[$" not in frm and not has_tag(frm):
                rep.add("WARN", e, "From has no tag: add ;tag=[call_number]")
            to = (hget(headers, "to") or [""])[0]
            to_low = to.lower()
            if is_resp and status != "100" and to:
                if "[last_to:]" in to_low:
                    if not has_tag(to) and not established and status[0] in "12":
                        rep.add("WARN", e, "the first %s of the dialog copies the To of the request without adding "
                                           ";tag=[call_number]: the response needs a To tag" % status)
                elif not has_tag(to):
                    rep.add("WARN", e, "response To has no tag")
            if is_resp and status != "100" and has_tag(to):
                established = True
            if is_resp and status == "100" and ";tag=" in to_low:
                rep.add("INFO", e, "100 Trying usually has no To tag")
            if method in ("ACK", "BYE", "PRACK", "UPDATE", "INFO", "REFER") and role == "client" and to \
                    and not has_tag(to) and "[$" not in to and "[last_to:]" not in to_low:
                rep.add("WARN", e, "in-dialog %s: To needs the peer's tag, e.g. 'To: <...>;[peer_tag_param]'" % method)
            cseq = (hget(headers, "cseq") or [""])[0]
            if cseq and "[last_cseq:]" not in cseq.lower() and not re.match(r"^\[\$\w+\]$", cseq.strip()):
                m = re.match(r"^(\S+)\s+(\S+)\s*$", cseq)
                if not m:
                    rep.add("WARN", e, "CSeq must be '<number> <METHOD>', e.g. '[cseq+1] INVITE'")
                else:
                    num, cm = m.group(1), m.group(2)
                    if not (num.isdigit() or re.match(r"^\[(cseq([+-]\d+)?|\$\w+([+-]\d+)?|val_last_CSeq:)\]$", num)):
                        rep.add("WARN", e, "CSeq number '%s' is not a number or [cseq] keyword" % num)
                    if num.isdigit() and int(num) >= 2 ** 31:
                        rep.add("WARN", e, "CSeq number must be below 2^31")
                    if method and concrete(cm) and cm != method:
                        rep.add("WARN", e, "CSeq method %s does not match the request method %s" % (cm, method))
                    if method in ("ACK", "CANCEL") and num.startswith("[cseq+"):
                        rep.add("WARN", e, "%s uses the CSeq number of its INVITE: [cseq], not %s" % (method, num))
            cl = headers.get("content-length") or headers.get("l") or []
            has_body = any(l.strip() for l in body)
            if has_body and (not cl or cl[0] != "[len]"):
                rep.add("WARN", e, "the message has a body: use 'Content-Length: [len]' so the program counts the bytes")
            if not has_body and not cl:
                rep.add("WARN", e, "no Content-Length (add 'Content-Length: 0'; over TCP/TLS it is required)")
            ctype = (headers.get("content-type") or headers.get("c") or [""])[0].lower()
            if "application/sdp" in ctype:
                check_sdp(e, body, rep)
            if has_body and not ctype:
                rep.add("WARN", e, "a body without a Content-Type header")
            cid = (hget(headers, "call-id") or [""])[0]
            if cid and "[last_call-id:]" not in cid.lower() and "[$" not in cid:
                if method in DIALOG_STARTERS and not has_tag(to):
                    call_id = cid
                elif call_id is None:
                    call_id = cid
                elif cid != call_id:
                    rep.add("WARN", e, "Call-ID '%s' differs from '%s' earlier in this dialog (a new dialog needs cmd_NewDialog)"
                            % (cid, call_id))
            for l in hdr_lines:
                if re.search(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", l) and not l.lower().startswith(("record-route", "route")):
                    rep.add("INFO", e, "a literal IP address in '%s': [local_ip]/[remote_ip] keep the file portable"
                            % l.strip()[:60])
                    break
            if media_running and method in ("BYE", "CANCEL") and not waits:
                rep.add("WARN", e, "%s right after %s with no pause: the media stops at once. Add cmd_Pause=<ms> before it"
                        % (method, media_running.title()))
            if media_running and method in ("BYE", "CANCEL"):
                media_running = None
            waits = False

        if e.kind in ("pcap", "speech"):
            # a pcap with ;duration=N holds the call for N ms by itself
            media_running = None if re.search(r";duration=", e.text) else e
            waits = False
        if e.kind in ("pause", "waitrtp", "waitvideo"):
            waits = True

        if e.kind == "pause":
            v = e.text[len("cmd_Pause="):].strip()
            if not (v.isdigit() or re.match(r"^\[\$\w+\]$", v) or re.match(r"^\[field(\d+|:.+)\]$", v)):
                rep.add("ERROR", e, "cmd_Pause takes milliseconds or a keyword such as [$delay], not '%s'" % v)
        elif e.kind == "pcap":
            args = e.text[len("cmd_PlayPcap="):].split(";")
            p = args[0].strip()
            for a in args[1:]:
                a = a.strip()
                if not (re.match(r"^duration=(\d+|\[\$\w+\])$", a) or a in ("video=true", "video=false")):
                    rep.add("WARN", e, "cmd_PlayPcap option '%s' is not duration=<ms> or video=true" % a)
            if not p:
                rep.add("ERROR", e, "cmd_PlayPcap without a file")
            elif root and "[" not in p:
                full = p if os.path.isabs(p) else os.path.join(root, p.replace("\\", os.sep))
                if not os.path.isfile(full):
                    rep.add("WARN", e, "pcap file not found: %s" % full)
            if p.lower().endswith(".mp4") and "video=true" not in e.text:
                rep.add("WARN", e, "an MP4 file plays as video: add ;video=true")
        elif e.kind == "digits":
            m = re.match(r"^cmd_DialDigits=([^;]*)(?:;PT=(.*))?$", e.text)
            digits = m.group(1).strip() if m else ""
            if not digits:
                rep.add("ERROR", e, "cmd_DialDigits has no digits")
            elif "[" not in digits and not re.match(r"^[0-9*#A-Da-d]+$", digits):
                rep.add("ERROR", e, "cmd_DialDigits keys are 0-9, *, # and A-D, not '%s'" % digits)
            if m and m.group(2) is not None and m.group(2).strip() and not (m.group(2).strip().isdigit() and int(m.group(2)) <= 127):
                rep.add("ERROR", e, "cmd_DialDigits PT must be 0-127")
        elif e.kind == "setvar":
            parts = re.findall(r'"[^"]*"|\S+', e.text[len("set_Variable="):])
            if len(parts) < 3:
                rep.add("ERROR", e, "set_Variable=<name> \"<header>\" \"<expression>\" needs three parts")
            else:
                hdr, expr = parts[1].strip('"'), parts[2].strip('"')
                if hdr == "-" and not expr.startswith("="):
                    rep.add("ERROR", e, "with header \"-\" the expression assigns a value and starts with =, e.g. \"=500\"")
                if hdr != "-" and "*" not in expr:
                    rep.add("ERROR", e, "the expression needs a * for the part to take, e.g. \"tag=*\"")
        elif e.kind == "save":
            if not re.match(r"^[A-Za-z_]\w*=save\((SDP|REMOTE_IP_PORT)\)$", e.text):
                rep.add("ERROR", e, "use <name>=save(SDP) or <name>=save(REMOTE_IP_PORT)")
        elif e.kind == "rand":
            m = re.match(r"^[A-Za-z_]\w*=rand\[(\d+)-(\d+)\]$", e.text)
            if not m:
                rep.add("ERROR", e, "use <name>=rand[<start>-<end>]")
            elif int(m.group(1)) > int(m.group(2)):
                rep.add("ERROR", e, "rand start is bigger than end")
        elif e.kind == "goto":
            t = e.text[len("goto="):].strip()
            if t not in labels:
                rep.add("ERROR", e, "goto target '%s' has no label=%s" % (t, t))
        elif e.kind == "condition":
            body = e.text[len("condition="):].strip()
            m = CONDITION.match(body)
            if not m:
                rep.add("ERROR", e, "condition cannot be read; use condition=if (<var> <op> <value>) goto <label>, "
                                    "op one of == != < <= > >= has")
            else:
                var, target = m.group(1), m.group(6)
                if target not in labels:
                    rep.add("ERROR", e, "condition target '%s' has no label=%s" % (target, target))
                if var in ("Resp", "REQ"):
                    pass
                elif var not in ("[CCnt]", "CCnt") and var.lstrip("$") not in defined:
                    rep.add("WARN", e, "condition on '%s', which no set_Variable/save/rand sets" % var)
        elif e.kind == "assert":
            a = e.text[len("assert="):].strip()
            ok = (re.match(r"^status\s+([1-6]\d\d|[1-6]xx)(\|([1-6]\d\d|[1-6]xx))*$", a, re.I)
                  or re.match(r"^responseTime\s+\d+$", a, re.I)
                  or re.match(r"^header\s+\S+\s+(exists|absent|empty|notEmpty)$", a, re.I)
                  or re.match(r"^header\s+\S+\s+(contains|equals|matches)\s+.+$", a, re.I)
                  or re.match(r"^body\s+(empty|notEmpty)$", a, re.I)
                  or re.match(r"^body\s+(contains|equals|matches)\s+.+$", a, re.I)
                  or ASSERT_RTP.match(a))
            if not ok:
                rep.add("ERROR", e, "assertion cannot be read (it would fail every call): see the Assertions table in format.md")
        elif e.kind == "waitvideo":
            if not re.match(r"^waitVideo=\d+(;timeout=\d+)?$", e.text):
                rep.add("ERROR", e, "use waitVideo=<pictures>[;timeout=<ms>]")
        elif e.kind == "remote":
            v = e.text[len("cmd_setRemote="):].strip()
            if not v:
                rep.add("ERROR", e, "cmd_setRemote without an address")
        elif e.kind == "spec":
            if not re.match(r"^cmd_Spec=setCC\((\d+|\[\$\w+\])\)$", e.text):
                rep.add("WARN", e, "the only special command is cmd_Spec=setCC(<n>)")

    # optional sends must follow an optional receive
    for idx, e in enumerate(entries):
        if e.kind == "send" and e.optional:
            prev = next((x for x in reversed(entries[:idx]) if x.kind in ("send", "recv")), None)
            if prev is None or not prev.optional:
                rep.add("WARN", e, "an optional send goes out only when the optional incoming message before it arrived; "
                                   "the message before this one is not optional")

    if outline:
        print("// SIP Messages (%s)" % (role or "no messages"))
        for e in entries:
            if e.kind in ("send", "recv"):
                first = e.start
                if e.kind == "send":
                    first = re.sub(r"^SIP/2\.0 ", "", first)
                    first = first.split(" ")[0] if not first[:3].isdigit() else first
                print("//  %s %s%s" % ("--->" if e.kind == "send" else "<---", first, " (optional)" if e.optional else ""))
            elif e.kind == "newdialog":
                print("//  (new dialog)")
            elif e.kind not in ("bad", None):
                print("//  ---- %s" % e.text)
    return rep


def main():
    ap = argparse.ArgumentParser(description="Check SIP Inspector scenario files.")
    ap.add_argument("files", nargs="+")
    ap.add_argument("--root", help="SIP Inspector folder, to check that pcap files exist")
    ap.add_argument("--outline", action="store_true", help="print the call flow")
    ap.add_argument("-q", "--quiet", action="store_true", help="do not print INFO")
    args = ap.parse_args()
    worst = 0
    for path in args.files:
        rep = check(path, args.root, args.outline)
        if rep is None:
            worst = 2
            continue
        shown = sorted((i for i in rep.items if not (args.quiet and i[1] == "INFO")), key=lambda i: i[0])
        for _, level, where, msg in shown:
            print("%s: %-5s %s: %s" % (path, level, where, msg))
        e, w = rep.count("ERROR"), rep.count("WARN")
        print("%s: %d error(s), %d warning(s)%s" % (path, e, w, "" if e else " - OK to load"))
        if e and worst < 1:
            worst = 1
    sys.exit(worst)


if __name__ == "__main__":
    main()
