# SIP Inspector scenario format reference

Contents
1. File structure and separators
2. SIP message entries
3. Keywords
4. Commands (pause, media, routing, dialogs)
5. Labels, goto and conditions
6. Variables
7. Assertions
8. Values files
9. Message templates that work

## 1. File structure and separators

- Everything before the first separator line is the header comment. `//` lines are comments
  anywhere and are kept when the GUI saves the file.
- A separator line starts every entry:

| Separator | Entry |
|---|---|
| `---------->` | a SIP message the program sends |
| `---------->*` | an optional send: sent only if the optional incoming message before it arrived |
| `---------->;retrans` | over UDP, send again until answered (RFC 3261): an INVITE after T1, 2T1, 4T1 ... until any response; another request the same but at most T2 apart, until a final response; a final response to an INVITE (2xx to 6xx) until the ACK. Gives up after 64*T1 and the call ends as timed out. Each copy may be answered again: a response, or an ACK, that comes once more is dropped (a final response to the INVITE gets the ACK again), not unexpected. `*` may come before `;` |
| `<----------` | a SIP message the program waits for |
| `<----------*` | an optional incoming message: it may or may not come |
| `<----------;retrans` | the other side may send this message again over UDP: a copy is answered with what answered it (the same response, or the ACK again), or dropped when it was not answered yet, and is not unexpected. Kept for 64*T1 after the call ended, for a BYE whose 200 OK was lost |
| `----------` | any other entry (command, variable, label, condition, assertion) |

- `;retrans` goes on both sides of a pair: the sender flags what it sends again, the receiver the same
  message as it expects it (INVITE, 200 OK to the INVITE, BYE ...). T1 and T2 are run settings (`-t1`,
  `-t2`, 500 and 4000 ms by default), never per message. Over TCP, TLS and WebSocket `;retrans` does nothing.
  `;ReTxCnt=N` is the earlier format: the program reads it as `;retrans`; do not write it.
- One entry per block. A block is read by its first recognised line; anything after that is lost.
- A block that no entry type knows is ignored with a warning in SIPInspector.log, and the call later
  fails on the missing step.
- Both LF and CRLF files load. Write LF.

## 2. SIP message entries

**Incoming** (`<----------`): only the start line, e.g. `INVITE`, `ACK`, `BYE`, `100 Trying`,
`180 Ringing`, `183 Session Progress`, `200 OK`, `401 Unauthorized`, `407 Proxy Authentication Required`.
A request matches on its method, a response on its status code.

**Outgoing** (`---------->`): the full message, line by line:

```
<start line>
<header>: <value>
...
Content-Length: [len]
<empty line>
<body, if any>
```

- A request start line: `METHOD sip:user@host:port SIP/2.0`. A response: `SIP/2.0 200 OK`.
- Headers that are copied from the last received message are written as keywords on a line of their
  own: `[last_Via:]`, `[last_From:]`, `[last_To:]`, `[last_Call-ID:]`, `[last_CSeq:]`,
  `[last_Contact:]`, `[last_Record-Route:]` ... (`[last_Via:]` gives all Via headers). Text after the
  keyword is appended to that header line, e.g. `[last_To:];tag=[call_number]`.
- Custom methods and status codes are fine: write whatever start line is needed.
- Multipart bodies: `Content-Type: multipart/mixed;boundary=level-0`, parts separated by `--level-0`,
  the last delimiter `--level-0--[no_\r\n]`. Binary bodies: `[hex]080200017b70028034[/hex][no_\r\n]`.
  See HexBody_client.txt.

## 3. Keywords

Written in square brackets, replaced before a message is sent. A keyword the program does not know is
sent as it is. A literal `[` (e.g. IPv6 in a URI) is written `[[`.

| Keyword | Value |
|---|---|
| `[local_ip]` | local IP (IPv6 in brackets). CLI `-lip` |
| `[local_ip_sdp]` | local IP for SDP (IPv6 without brackets) |
| `[local_port]` | local SIP port (`-lp`); for TCP/TLS clients the real ephemeral port |
| `[remote_ip]` | remote IP (`-rip`); in server mode the address the last message came from; after `cmd_setRemote` that target |
| `[remote_port]` | remote port (`-rp`), same rules |
| `[transport]` | UDP, TCP, TLS, WS or WSS (`-t`) |
| `[IP_ver]` | IP4 or IP6 (`-ip v4|v6`), for SDP |
| `[media_port]` | local RTP port (`-lrtp`, +2 per call) |
| `[video_port]` | local video RTP port of this call |
| `[fromUsername]` / `[toUsername]` | account From / To users (`-uf` / `-ut`) |
| `[authUsername]` / `[authPassword]` | auth user / password (`-au` / `-ap`) |
| `[authentication username=X; password=Y;]` | whole digest value for Authorization / Proxy-Authorization, computed from the last 401/407. X and Y may be keywords: `username=[authUsername]; password=[authPassword];` |
| `[branch]` | Via branch: z9hG4bK + a tag new for each run + call counter + entry position, e.g. `z9hG4bKq3x8f0ka.1.5` (unique per entry and run) |
| `[call_number]` | global call counter; a new dialog of the same call gets a `-N` suffix |
| `[run_tag]` | 8 random characters, new for each run: in the Call-ID (`[call_number].[run_tag]@[local_ip]`) and a branch written by hand, so they are not those of an earlier run |
| `[CCnt]` | number of calls running now |
| `[cseq]` | current CSeq of the call |
| `[cseq+N]` / `[cseq-N]` | adds/subtracts N, the new value is used and kept |
| `[peer_tag_param]` | `tag=...` of the peer: From tag if the last received message was a request, To tag if a response; empty if none |
| `[last_Header:]` | the whole header line(s) of the last received message |
| `[val_last_Header:]` | only the value, e.g. `RAck: [val_last_RSeq:] [val_last_CSeq:]` |
| `[len]` | body length in bytes |
| `[ver]` | program version |
| `[fieldN]` / `[field:name]` | column N (0-based) / named column of the values file row of this call |
| `[$var]` | user variable; `[$var+N]` / `[$var-N]` returns it and then changes it by N |
| `[hex]...[/hex]` | hex digits sent as bytes |
| `[no_\r\n]` | at the end of a body line: do not add CRLF |

## 4. Commands

| Entry | Meaning |
|---|---|
| `cmd_Pause=2000` | pause 2000 ms; a keyword such as `[$delay]` is allowed |
| `cmd_PlayPcap=./pcap/test.pcap` | stream the RTP of a pcap (any codec recorded in it) to the far end's SDP address; loops if shorter than the pause after it |
| `cmd_PlayPcap=./pcap/test.pcap;duration=15000` | play for 15 s; the call waits here while it plays |
| `cmd_PlayPcap=./pcap/video_h264.mp4;video=true` | send video (H.264 pcap or MP4) too |
| `cmd_RTPSpeech` | live two-way speech from the sound device (PCMU, PCMA, G.729). Needs a sound device |
| `cmd_RTPEcho` | send back the RTP that arrives |
| `cmd_DialDigits=1234;PT=101` | RFC 4733 DTMF digits (0-9 * # A-D); PT optional. Digits can be `[$var]` or `[fieldN]`. Without PT the payload type of the far end's SDP is used |
| `waitRTP` | continue when the first RTP packet arrives (no time limit) |
| `waitVideo=30;timeout=15000` | continue when 30 video pictures were decoded; fails after the timeout (CLI needs `-pv`) |
| `cmd_setRemote=192.168.1.110:5060` | send the next messages to this address (default port 5060); `[$var]` allowed. For 3PCC, B2BUA, Route handling |
| `cmd_setMediaPort=7000` | change the local RTP port |
| `cmd_NewDialog` | the following messages form a new dialog with its own Call-ID |
| `cmd_Spec=setCC(10)` | set max concurrent calls while running; `setCC([$n])` allowed |

Pcap files that come with the program: `pcap/test.pcap` (PCMU speech), `pcap/711aLaw.pcap`,
`pcap/G729.pcap`, `pcap/dtmf_0.pcap` ... `dtmf_9.pcap`, `dtmf_star.pcap`, `dtmf_pound.pcap`,
`pcap/video_h264.pcap`, `pcap/video_h264.mp4`. Paths are relative to the program folder.

Media must be given time: after `cmd_PlayPcap` (without duration) and `cmd_RTPSpeech` the scenario goes
on immediately, so add `cmd_Pause` before an outgoing BYE (a server that waits for `<---------- BYE` does
not need it). With `;duration=N` the call waits N ms at that entry. Two timed pcaps one after the other
change the codec in mid-call (Call_codec_change_rtp_only_client.txt). A pcap shorter than the time it plays starts over.

## 5. Labels, goto and conditions

```
----------
label=start

----------
goto=start

----------
condition=if (Resp == 404) goto end
```

Condition syntax: `condition=if (<var>[/N|%N] <op> <value>) goto <label>`

- `<op>`: `==`, `!=`, `<`, `<=`, `>`, `>=`, `has` (contains).
- `/N` and `%N` divide or take the remainder first: `Resp/100 == 1` (any 1xx), `Resp%400 == 7` (407).
- `Resp` (status code) and `REQ` (method) test the **next incoming message**: put the condition where
  the scenario waits for it. If it holds, the condition takes the message and the call jumps to the label;
  otherwise the message is matched against the entries that follow. Several such conditions in a row
  are all tested against the same message (Reg_auth_call_advanced_client.txt).
- Other variables are tested where the condition stands: `[CCnt]` (calls now running) or a user
  variable name (`if (user == 1000) goto end`, where `user` was set by set_Variable).
- Every target label must exist. Labels are unique.

Example - one REGISTER flow whatever the server does:

```
---------->
REGISTER ...

----------
condition=if (Resp == 404) goto end

<----------*
100 Trying

<----------*
401 Unauthorized

---------->*
REGISTER ... (with Authorization)

<----------
200 OK

----------
label=end
```

## 6. Variables

Variables belong to the call (each call has its own values) and are used as `[$name]`.

| Entry | Meaning |
|---|---|
| `set_Variable=toTag "To:" "tag=*"` | from the last message (sent or received), header To, the part the `*` matches |
| `set_Variable=user "From:" "<sip:*@"` | user part of a URI |
| `set_Variable=contact "Contact:" "<*>"` | the URI inside < > |
| `set_Variable=route1 "Record-Route-1:" "*"` | the first instance of a repeated header (`-2`, `-3` ...) |
| `set_Variable=ruri "startline" "INVITE * SIP/2.0"` | from the start line (it has no header name) |
| `set_Variable=delay "-" "=500"` | assign a value; `"=[$a]+1000"` does + - * / on whole numbers |
| `sdp1=save(SDP)` | save the whole SDP body of the last message; send it later as a body line `[$sdp1]` |
| `rem1=save(REMOTE_IP_PORT)` | save where the last message came from as IP:port, e.g. for `cmd_setRemote=[$rem1]` |
| `rndVal=rand[1000000-9999999]` | random whole number in the range (inclusive) |

Star matching: the text before `*` and after `*` are searched for, what is between is the value. With
nothing before `*` the value is everything up to the text after it; with nothing after `*`, everything
after the text before it. `"*"` alone is the whole header value.

Put a `set_Variable` directly after the message it reads.

## 7. Assertions

An assertion checks the call so far; when it fails the step is counted unexpected, the call is dropped
and the CLI exits with 1. Place it right after the message it checks; RTP assertions after a pause,
just before the BYE.

| Entry | Passes when |
|---|---|
| `assert=status 200` | last response is 200; also `2xx`, `180|183` |
| `assert=responseTime 500` | last response came within 500 ms of the last request sent |
| `assert=header Contact exists` | header present (`absent`: not present); short forms count |
| `assert=header User-Agent contains Fortinet` | also `equals`, `matches <regex>`, `empty`, `notEmpty`; case ignored |
| `assert=body contains PCMU` | body (SDP) of the last message; also `equals`, `matches`, `empty`, `notEmpty` |
| `assert=rtp packets > 100` | RTP packets received so far |
| `assert=rtp loss <= 1` | percent lost |
| `assert=rtp jitter < 30` | jitter ms |
| `assert=rtp mos >= 3.8` | estimated MOS |

RTP comparisons: `<`, `<=`, `>`, `>=`, `==`. Sample: Call_speech_dials_asserts_client.txt.

## 8. Values files

One row per call, used in turn (the CLI `-fvo` / Options/Use Each Values Row Once uses each row once).

```
#columns: user;password;name
1000;secret1000;Alice
1001;secret1001;Bob
```

- Separator `;` (a `;` in a value is `\;`), no spaces around it; `//` or `#` lines are comments.
- `.csv` files: commas, the first line names the columns, quotes allowed.
- `start+step` counts: `5000000+1` gives 5000000, 5000001 ...
- In the scenario: `[field0]` or `[field:user]`, e.g.
  `Authorization: [authentication username=[field:user]; password=[field:password];]`.
- CLI: `-fv values/file.txt`. Samples: `values/Reg_series_values.txt`, `values/PBX_call_series_values.txt`.

## 9. Message templates that work

Client INVITE with audio (offer PCMU and DTMF; add `8` for PCMA, `18` + `a=rtpmap:18 G729/8000` for G.729):

```
---------->
INVITE sip:[toUsername]@[remote_ip]:[remote_port] SIP/2.0
Via: SIP/2.0/[transport] [local_ip]:[local_port];branch=[branch]
From: <sip:[fromUsername]@[local_ip]:[local_port]>;tag=[call_number]
To: <sip:[toUsername]@[remote_ip]:[remote_port]>
Call-ID: [call_number].[run_tag]@[local_ip]
CSeq: [cseq+1] INVITE
Max-Forwards: 70
Contact: <sip:[fromUsername]@[local_ip]:[local_port];transport=[transport]>
User-Agent: SIPInspector_v_[ver]
Content-Type: application/sdp
Content-Length: [len]

v=0
o=111 843670094 843670094 IN [IP_ver] [local_ip_sdp]
s=-
c=IN [IP_ver] [local_ip_sdp]
t=0 0
a=sendrecv
m=audio [media_port] RTP/AVP 0 101
a=rtpmap:0 PCMU/8000
a=rtpmap:101 telephone-event/8000
a=fmtp:101 0-15
a=ptime:20
```

Client ACK for the 200 OK (BYE is the same with `CSeq: [cseq+1] BYE`):

```
---------->
ACK sip:[toUsername]@[remote_ip]:[remote_port] SIP/2.0
Via: SIP/2.0/[transport] [local_ip]:[local_port];branch=[branch]
From: <sip:[fromUsername]@[local_ip]:[local_port]>;tag=[call_number]
To: <sip:[toUsername]@[remote_ip]:[remote_port]>;[peer_tag_param]
Call-ID: [call_number].[run_tag]@[local_ip]
CSeq: [cseq] ACK
Max-Forwards: 70
Contact: <sip:[fromUsername]@[local_ip]:[local_port];transport=[transport]>
Content-Length: 0

```

Client REGISTER (`CSeq: [cseq] REGISTER` the first time, `[cseq+1]` for the one with credentials):

```
---------->
REGISTER sip:[remote_ip]:[remote_port] SIP/2.0
Via: SIP/2.0/[transport] [local_ip]:[local_port];branch=[branch]
From: <sip:[fromUsername]@[remote_ip]:[remote_port]>;tag=24de4a5dbe4ef
To: <sip:[fromUsername]@[remote_ip]:[remote_port]>
Call-ID: [call_number].[run_tag]@[local_ip]
CSeq: [cseq] REGISTER
Max-Forwards: 70
Contact: <sip:[fromUsername]@[local_ip]:[local_port];transport=[transport]>
Expires: 3600
User-Agent: SIPInspector_v_[ver]
Content-Length: 0

```

Server responses to an INVITE (100 without a To tag; 180 and 200 add the tag; 200 carries the answer SDP,
same SDP shape as the INVITE above):

```
---------->
SIP/2.0 180 Ringing
[last_Via:]
[last_From:]
[last_To:];tag=[call_number]
[last_Call-ID:]
[last_CSeq:]
Contact: <sip:[local_ip]:[local_port];transport=[transport]>
User-Agent: SIPInspector_v_[ver]
Content-Length: 0

```

Server 200 OK to a BYE (the To of the BYE already has the tag, so no `;tag=`):

```
---------->
SIP/2.0 200 OK
[last_Via:]
[last_From:]
[last_To:]
[last_Call-ID:]
[last_CSeq:]
Content-Length: 0

```

A server that sends its own in-dialog request (BYE, NOTIFY, re-INVITE) needs the dialog identifiers saved
from the INVITE with `set_Variable` (Call-ID, From, To with tag, Contact) and built from them; see
Call_transfer_server.txt (NOTIFY, BYE) and Reg_subscribe_call_server.txt (NOTIFY).
