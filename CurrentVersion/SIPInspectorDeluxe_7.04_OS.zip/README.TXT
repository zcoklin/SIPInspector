 *******************************************************************************
 *                                                                             *
 *  LICENSE AGREEMENT:                                                         *
 *                                                                             *
 *  SIP Inspector Pro is paid for software and MUST not be used without a      *
 *  valid license. For more information have a look at License.txt file        *
 *                                                                             *
 *  To report problems related with the tool, for licensing inquiries please   *
 *                                                                             *
 *                      support@sipinspector.com                               *
 *                                                                             *
 *  To discuss issue with other visit:                                         *
 *       https://groups.google.com/forum/#!forum/sip-inspector                 *
 *                                                                             *
 *  To obtain a license key, please provide Machine-ID with a proof of         *
 *  payment and license key will be sent through email.                        *
 *                                                                             *
 *******************************************************************************

Visit SIP Inspector web site for more details: http://www.sipinspector.com

Writing scenarios with Claude
  The program comes with a skill for Claude, the AI assistant of Anthropic (an account at
  claude.ai is needed; SIP Inspector sends nothing to it). With it Claude writes scenarios from a
  description of the call, writes both sides and plays them against each other on this computer,
  makes a scenario from a Wireshark capture, explains why a run failed and fixes the scenario.
  * Claude Code: the skill is in .claude/skills/sip-inspector-scenarios. Open a terminal in this
    folder, start claude and describe the call.
  * claude.ai: upload sip-inspector-scenarios.skill under Settings/Capabilities/Skills (code
    execution on) and attach the closest sample scenario to the chat.
  See the chapter Writing scenarios with Claude in the manual.
Rel 6.06
  * Corrected pause duration. Pauses were not that accurate and could be seconds off
  * Improved RTP streaming from a pcap file. Bug forced RTP streaming of codec supported. After the
    fix it is possible to stream from a file any recorded codec
  * Fixed a bug where audio was not locally played if scenario is re-ran multiple times in consecutively
  * Fixed a bug which caused outgoing SIP messages not being logged when SIP logging is enabled 

Rel 6.04
Bug fixes:
 * Fixed RTP echo mode. The bug caused 2 RTP ports being used and possibly 2 RTP packets sent back

Rel 6.02
Bug fixes:
 * Fixed the GUI issue which affected users having a lot of local IP addresses.  

Rel 6.00
New features:
* SRTP for both live speech or when sending a pcap file
* Ability to play RTP when using WebSockets
* Improved performance to allow high call speeds 300+ cps
* improved logic which allows 300+ simultaneous RTP streams
* when audio is plaid from a pcap file audio progress is kept separately for each remote side
* G729 is supported
* ability to send multipart SDP bodies
* ability to send hexadecimal content in SDP bodies
* client scenario can have multiple dialogs (registration and outgoing sip calls are now possible in the same scenario file)
* new logic to store license information to improve user experience when upgrading an OS, for example
Bug fixes:
 * fixed a bug which caused incorrect logic when switching between playing digits and pauses several times in a row
 * RTP streams were not played when switching codec in a middle of call
 * sometimes a few packets with incorrect SSRC number were present in an RTP stream
 * numerous other bug fixes

